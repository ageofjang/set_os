#================
#!/bin/sh
rm -rf cscope.files cscope.files
#find . \( -name '*.c' -o -name '*.cpp' -o -name '*.cc' -o -name '*.h' -o -name '*.s' -o -name '*.S' \) -print > cscope.files
find . \( -name '*' -name '*.c' -o -name '*.asm' -o -name '*.cpp' -o -name '*.cc' -o -name '*.h' -o -name '*.sh' \) -print > cscope.files
cscope -i cscope.files
#============================================
