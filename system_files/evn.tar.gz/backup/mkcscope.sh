#================
#!/bin/sh
rm -rf cscope.files cscope.files
find . \( -name '*.c' -o -name '*.cpp' -o -name '*.cc' -o -name '*.sql' -o -name '*.h' -o -name '*.mal'  -o -name '*.y' -o -name 'Makefile' -o -name '*.in' -o -name '*.s' -o -name '*.S' -o -name '*.py' \) -print > cscope.files
cscope -i cscope.files
#============================================
