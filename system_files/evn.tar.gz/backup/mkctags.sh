#================
#!/bin/sh
find . -type f -iname "*.[chs]" -o -iname "*.cxx" -o -name "*.hxx" | xargs ctags -a
